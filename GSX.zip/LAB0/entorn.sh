#!/bin/bash
mkdir GSX
mkdir GSX/LAB0
mkdir GSX/JP0
echo "angel.gascon@estudiants.urv.cat" > GSX/LAB0/alumne.txt